/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.model.dao;

import br.com.caelum.vraptor.Result;
import com.mycompany.model.entity.Pessoa;
import java.util.List;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 *
 * @author jamylle.magalhaes
 */
@Dependent
public class PessoaDAO {
    @Inject
    EntityManager manager;
    
    public void salvar(Pessoa p){
        manager.getTransaction().begin();
        manager.persist(p);
        manager.getTransaction().commit();
    }
    
    public Pessoa buscar(Long id){
        Pessoa p = manager.find(Pessoa.class, id);
        return p;
    }
    
    public List<Pessoa> pessoas(){
        Query query = manager.createQuery("from Pessoa");
        return query.getResultList();
    }    
        
    public void remove(Long id){
        manager.getTransaction().begin();
        Pessoa p = manager.find(Pessoa.class, id);
        manager.remove(p);
        manager.getTransaction().commit();
    }

    public void update(Pessoa pessoa){
        manager.getTransaction().begin();
        manager.merge(pessoa);
        manager.getTransaction().commit();
    }
}

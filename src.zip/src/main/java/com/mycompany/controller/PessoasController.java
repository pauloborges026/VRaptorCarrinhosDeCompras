/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.controller;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Result;
import com.mycompany.model.dao.PessoaDAO;
import com.mycompany.model.entity.Pessoa;
import java.util.List;
import javax.inject.Inject;

/**
 *
 * @author jamylle.magalhaes
 */
@Controller
public class PessoasController {
    @Inject
     PessoaDAO dao;
    
    @Inject
    private Result result;
    
    public void form(){
    }
   
    public List<Pessoa> lista(){
        return dao.pessoas();
    }
    
    public void salvar(Pessoa pessoa){
        if(pessoa.getId() == null){
            dao.salvar(pessoa);
        }
        else{
            dao.update(pessoa);
        }
        result.redirectTo(this).lista();
    }
    
    public void editar(Long cod){
        Pessoa pessoa = dao.buscar(cod);
        //faz a inclusão do obj pessoa na página form.jsp
        result.include(pessoa);
        //redireciona para form.jsp
        result.of(this).form();  
    }
    
    public void excluir(Long id){
      dao.remove(id);
        //redireciona para listar.jsp
        result.redirectTo(this).lista();
    }
}
